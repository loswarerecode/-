# OxideESP — Oxide Survival Island ESP

Non-root ESP overlay for **Oxide: Survival Island**.  
Runs via **GBox** (parallel space) — no root needed.

---

## Features

| Feature | Status |
|---|---|
| Player ESP boxes | ✅ |
| Player names | ✅ |
| Health bar (color-coded) | ✅ |
| Distance display | ✅ |
| Team tags | ✅ |
| Configurable max range | ✅ (100 / 200 / 300 / 500 m) |
| Floating draggable menu ⚙ | ✅ |

---

## How it works

1. GBox creates a parallel user namespace — apps inside share the same UID.
2. `/proc/<pid>/mem` is readable between processes with the same UID (no root).
3. OxideESP reads `libil2cpp.so` base from `/proc/<pid>/maps`, resolves
   the `PlayerManager_TypeInfo` symbol, follows the IL2CPP static fields
   pointer to `clientPlayerList`, and iterates all connected players.
4. Draws a transparent `TYPE_APPLICATION_OVERLAY` canvas on top of the game.

### Key offsets (dump build `1_13_11915`)

| Field | Class | Offset |
|---|---|---|
| `clientPlayerList` static | `PlayerManager` static block | `+0x10` |
| `vitals` | `PlayerManager` | `+0xC8` |
| `nicklabel` | `PlayerManager` | `+0x130` |
| `character` (Transform) | `oh` (nicklabel) | `+0x30` |
| `Ljs` (current HP) | `GenericVitals` | `+0xB8` |
| `m_MaxHealth` | `GenericVitals` | `+0x88` |
| `userID` | `PlayerManager` | `+0x278` |
| `teamName` | `PlayerManager` | `+0x280` |
| `m_WorldCamera` | `FPManager` | `+0x20` |

---

## Build (GitHub Actions — automatic)

Push to `main` → Actions runs → download APK from **Artifacts**.

```
git clone https://github.com/YOUR_USER/OxideESP
cd OxideESP
git push origin main
```

Then go to **Actions → Build OxideESP APK → Artifacts → OxideESP-release**.

### Build locally

```bash
./gradlew assembleRelease
# APK: app/build/outputs/apk/release/app-release.apk
```

Requires JDK 17 + Android SDK.

---

## Installation & Usage

1. Install **GBox** from Play Store.
2. Add **Oxide: Survival Island** inside GBox.
3. Install **OxideESP.apk** also inside GBox (or sideload to the same GBox account).
4. Open OxideESP → grant overlay permission.
5. Launch Oxide inside GBox — ESP activates automatically.
6. Tap **⚙** (drag to reposition) to open the settings menu.

---

## Menu controls

- **Tap ⚙** — open/close settings
- **Drag ⚙** — move button anywhere
- **ESP ON/OFF** — master toggle
- **Names / Health / Distance / Box** — individual toggles
- **Show Team** — prepend team tag to name
- **Max Dist** — cycle visible range (100 → 200 → 300 → 500 → 100 m)

---

## Notes

- Camera matrix is read from the local player's `FPManager.m_WorldCamera` native pointer.
  If the camera hasn't loaded yet (loading screen), ESP boxes won't appear until in-game.
- IL2CPP managed strings are UTF-16LE; the reader handles this correctly.
- The ELF symbol `PlayerManager_TypeInfo` is exported in release builds.
  If a future update strips exports, the fallback ARM64 ADRP decoder kicks in.
