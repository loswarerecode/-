# Keep all ESP classes intact
-keep class com.oxidesp.cheat.** { *; }

# Keep /proc parsing reflection
-keepclassmembers class * {
    public *;
}

# Suppress warnings about missing Android classes
-dontwarn android.**
-dontwarn androidx.**
