package com.oxidesp.cheat;

import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.util.DisplayMetrics;

/**
 * Oxide Survival Island - ESP Overlay Service
 * Runs as a floating overlay (non-root, via GBox parallel space)
 *
 * Offsets from dump_1_13_11915 (Assembly-CSharp):
 *   PlayerManager (Oxide.PlayerManager : NetworkBehaviour)
 *     clientPlayerList  static  → 0x10
 *     vitals            field   → 0xC8  (PlayerVitals)
 *     nicklabel         field   → 0x130 (oh : MonoBehaviour)
 *     userID            field   → 0x278
 *     teamName          field   → 0x280
 *     characterModel    field   → 0x150
 *   GenericVitals (base of PlayerVitals via EntityVitals)
 *     Ljs  (current health float) → 0xB8
 *     m_MaxHealth                → 0x88
 *   oh (nicklabel component)
 *     character (Transform)  → 0x30
 *   LootObject (Oxide.LootObject : GKw)
 *     isLootable → 0xA8
 *   AnimalHealth
 *     <MaxHealth>k__BackingField → 0x20
 *     <WvC>k__BackingField       → 0x24  (current health)
 *
 * Memory reading uses MemReader (see MemReader.java) via /proc/<pid>/mem
 * which works inside GBox (same UID as target app).
 */
public class ESPOverlayService extends Service {

    private WindowManager wm;
    private ESPView espView;
    private WindowManager.LayoutParams params;

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        espView = new ESPView(this);

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;

        wm.addView(espView, params);

        // Start ESP update loop
        espView.startUpdating();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (espView != null) {
            espView.stopUpdating();
            wm.removeView(espView);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
