package com.oxidesp.cheat;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Launcher activity.
 * 1. Check SYSTEM_ALERT_WINDOW permission (needed for overlay in GBox).
 * 2. Start ESPOverlayService.
 * 3. Minimize.
 *
 * No root required — overlay runs via TYPE_APPLICATION_OVERLAY which
 * GBox grants to apps inside the parallel space.
 */
public class MainActivity extends Activity {

    private static final int REQ_OVERLAY = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("OxideESP — Permission required")
                    .setMessage("Allow overlay permission so the ESP can draw on top of the game.\n\n" +
                            "Tap OK → find OxideESP in the list → enable 'Display over other apps'.")
                    .setPositiveButton("Open Settings", (d, w) -> {
                        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName()));
                        startActivityForResult(i, REQ_OVERLAY);
                    })
                    .setNegativeButton("Cancel", (d, w) -> finish())
                    .show();
        } else {
            startESP();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                startESP();
            } else {
                Toast.makeText(this, "Overlay permission denied — ESP cannot run.", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }

    private void startESP() {
        startService(new Intent(this, ESPOverlayService.class));
        Toast.makeText(this, "OxideESP started! Launch Oxide Survival Island.", Toast.LENGTH_LONG).show();
        // Move to background
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Keep service running even if activity is destroyed
    }
}
